<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="GD tiles" tilewidth="16" tileheight="16" tilecount="4" columns="4">
 <image source="Sprite-0002.png" width="64" height="16"/>
 <tile id="1">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
</tileset>
